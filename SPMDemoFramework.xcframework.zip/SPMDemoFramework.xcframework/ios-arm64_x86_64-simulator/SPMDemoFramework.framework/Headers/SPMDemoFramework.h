//
//  SPMDemoFramework.h
//  SPMDemoFramework
//
//  Created by Reema Bhalani on 6/9/23.
//

#import <Foundation/Foundation.h>

//! Project version number for SPMDemoFramework.
FOUNDATION_EXPORT double SPMDemoFrameworkVersionNumber;

//! Project version string for SPMDemoFramework.
FOUNDATION_EXPORT const unsigned char SPMDemoFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SPMDemoFramework/PublicHeader.h>


